const header = document.getElementById("siteHeader");
const stickyCTA = document.querySelector(".mobile-sticky-cta");
const leadSection = document.getElementById("start");

document.getElementById("year").textContent = new Date().getFullYear();

window.addEventListener("scroll", () => {
  header.classList.toggle("scrolled", window.scrollY > 14);

  if (stickyCTA && leadSection) {
    const rect = leadSection.getBoundingClientRect();
    const inLead = rect.top < window.innerHeight * 0.65 && rect.bottom > 120;
    stickyCTA.classList.toggle("hide", inLead);
  }
}, { passive: true });

/* Scroll reveal */
const revealEls = document.querySelectorAll(".reveal");
if ("IntersectionObserver" in window) {
  const observer = new IntersectionObserver((entries) => {
    entries.forEach((entry) => {
      if (entry.isIntersecting) {
        entry.target.classList.add("is-visible");
        observer.unobserve(entry.target);
      }
    });
  }, { threshold: 0.12, rootMargin: "0px 0px -35px 0px" });

  revealEls.forEach((el) => observer.observe(el));
} else {
  revealEls.forEach((el) => el.classList.add("is-visible"));
}

/* Multi-step form */
const form = document.getElementById("leadForm");
const steps = Array.from(document.querySelectorAll(".form-step"));
const progressBar = document.getElementById("progressBar");
const stepLabel = document.getElementById("stepLabel");
const formError = document.getElementById("formError");
const success = document.getElementById("formSuccess");
const resetButton = document.getElementById("formReset");
let currentStep = 1;

function fieldsForStep(stepNumber) {
  return Array.from(
    document.querySelectorAll(`.form-step[data-step="${stepNumber}"] input[required]`)
  );
}

function isStepValid(stepNumber) {
  const required = fieldsForStep(stepNumber);
  const radioNames = [...new Set(
    required.filter(el => el.type === "radio").map(el => el.name)
  )];

  for (const name of radioNames) {
    const checked = document.querySelector(`input[name="${name}"]:checked`);
    if (!checked) return false;
  }

  for (const field of required.filter(el => el.type !== "radio" && el.type !== "checkbox")) {
    if (!field.value.trim()) return false;
    if (field.type === "email" && field.value && !field.checkValidity()) return false;
  }

  for (const field of required.filter(el => el.type === "checkbox")) {
    if (!field.checked) return false;
  }

  return true;
}

function showStep(number) {
  currentStep = number;
  steps.forEach(step => step.classList.toggle("active", Number(step.dataset.step) === number));
  stepLabel.textContent = `Step ${number} of ${steps.length}`;
  progressBar.style.width = `${(number / steps.length) * 100}%`;
  formError.textContent = "";
}

document.querySelectorAll(".form-next").forEach(button => {
  button.addEventListener("click", () => {
    if (!isStepValid(currentStep)) {
      formError.textContent = "Please answer this question before continuing.";
      return;
    }
    if (currentStep < steps.length) showStep(currentStep + 1);
  });
});

document.querySelectorAll(".form-back").forEach(button => {
  button.addEventListener("click", () => {
    if (currentStep > 1) showStep(currentStep - 1);
  });
});

form.addEventListener("submit", (event) => {
  event.preventDefault();

  if (!isStepValid(currentStep)) {
    formError.textContent = "Please complete the required fields before submitting.";
    return;
  }

  // Front-end prototype only:
  // When the destination is chosen, replace this block with a secure webhook/form handler.
  const payload = Object.fromEntries(new FormData(form).entries());
  console.log("Mandil Health prototype lead:", payload);

  steps.forEach(step => step.classList.remove("active"));
  document.querySelector(".form-top").style.display = "none";
  document.querySelector(".progress-track").style.display = "none";
  formError.textContent = "";
  success.classList.add("active");
});

resetButton.addEventListener("click", () => {
  form.reset();
  success.classList.remove("active");
  document.querySelector(".form-top").style.display = "";
  document.querySelector(".progress-track").style.display = "";
  showStep(1);
});

/* Auto-uppercase state */
const stateInput = document.getElementById("stateInput");
stateInput.addEventListener("input", () => {
  stateInput.value = stateInput.value.replace(/[^a-zA-Z]/g, "").toUpperCase().slice(0, 2);
});

/* FAQ: keep one open at a time */
document.querySelectorAll(".faq-list details").forEach(detail => {
  detail.addEventListener("toggle", () => {
    if (!detail.open) return;
    document.querySelectorAll(".faq-list details").forEach(other => {
      if (other !== detail) other.open = false;
    });
  });
});
