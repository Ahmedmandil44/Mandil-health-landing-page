MANDIL HEALTH — V3.1

Changes:
- Removed the advisor's personal name from all public-facing copy.
- Replaced personal references with neutral wording such as:
  "a licensed advisor will reach out"
  "one licensed advisor as your point of contact"
- Removed the public personal-name email address from the landing page.
- Added DM Serif Display as a selective accent font.
- Added font utility classes so individual phrases can be styled without redesigning the page.

Useful classes for future targeted edits:
  accent-serif
  inline-serif
  accent-small
  accent-tagline
  text-soft
  text-blue
  text-mint
  text-emphasis
  text-italic

This means future requests can be extremely specific:
- "Make 'without the runaround' serif."
- "Turn this exact phrase blue."
- "Change this sentence only."
- "Make the second half of this heading italic."

V3.2 cleanup:
- Reworked the footer contact area so it no longer looks like a redacted advisor profile.
- Replaced initials "AM" with "MH" brand initials where appropriate.
- Rewrote advisor/trust copy around licensed guidance rather than a named person.
- Footer now points users back to the coverage-review form instead of presenting a pseudo-contact card.


V3.3 changes:
- Richer/darker color system with deeper blues and teals.
- Replaced the Gmail-like mark with a shield/medical cross icon direction.
- Swapped ACA Marketplace content for Life Insurance content.
- Life Insurance section now references whole life and final expense.
- Updated surrounding copy, FAQ, hero microcopy, and form options to reflect health + life positioning.
